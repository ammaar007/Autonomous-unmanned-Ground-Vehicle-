#!/usr/bin/env python
#!/usr/bin/env python3
#!/usr/bin/env python2

import subprocess
import sys
import rospy
from std_msgs.msg import Int8

import sys
from PyQt5 import uic
from PyQt5 import QtWidgets
from PyQt5.QtCore import QMutex
from PyQt5.QtWidgets import QDialog, QApplication, QWidget , QPushButton
from PyQt5.QtGui import QPixmap
import bgimage
pub = rospy.Publisher('GUI', Int8, queue_size=12)
rospy.init_node('talker', anonymous=True)
rate = rospy.Rate(8)
value = 0


class WelcomeScreen(QDialog):
    def __init__(self):
        super(WelcomeScreen, self).__init__()
        uic.loadUi("rc_controller.ui", self)
        self.start.clicked.connect(self.gotomainpage)

    def gotomainpage(self):
        value = 1
        main = MainPage()
        widget.addWidget(main)
        widget.setCurrentWidget(widget.currentIndex()+1)


class MainPage(QDialog):
    def __init__(self):
        super(MainPage, self).__init__()
        uic.loadUi("mainpage.ui", self)
        self.RC.clicked.connect(self.goto_rc)

    def goto_rc(self):
        value = 2
        Rc = RcClass()
        widget.addWidget(Rc)
        widget.setCurrentWidget(widget.currentIndex()+1)


class RcClass(QDialog):
    def __init__(self):
        super(RcClass, self).__init__()
        uic.loadUi("rc_controller.ui", self)
        self.forward.clicked.connect(self.gotoforward)
        self.reverse.clicked.connect(self.gotoreverse)
        self.right.clicked.connect(self.gotoright)
        self.left.clicked.connect(self.gotoleft)
        self.fright.clicked.connect(self.gotofright)
        self.fleft.clicked.connect(self.gotofleft)
        self.rright.clicked.connect(self.gotorright)
        self.rleft.clicked.connect(self.gotorleft)
        self.stop.clicked.connect(self.Stop)
        self.loadmission.clicked.connect(self.Loadmission)
        self.loadmap.clicked.connect(self.Loadmap)
        self.arduino.clicked.connect(self.connectarduino)
        self.camera.clicked.connect(self.runcamera)
        self.autonomous.clicked.connect(self.Autonomous)



    def gotoforward(self):
        value = 1
        print(value)
        hello_str="FORWARD"
        rospy.loginfo(hello_str)
        pub.publish(value)

    def gotoreverse(self):
        value = 2
        print(value)
        hello_str="REVERSE"
        rospy.loginfo(hello_str)
        pub.publish(value)

    def gotoright(self):
        value = 3
        print(value)
        hello_str="RIGHT"
        rospy.loginfo(hello_str)
        pub.publish(value)

    def gotoleft(self):
        value = 4
        print(value)
        hello_str="LEFT"
        rospy.loginfo(hello_str)
        pub.publish(value)

    def gotofright(self):
        value = 5
        print(value)
        hello_str="FORWARD_RIGHT"
        #rospy.loginfo(hello_str)
        #subprocess.Popen("cd catkin_ws/src/qas/scripts;rosrun qas GUI2.py", shell=True)
        pub.publish(value)

    def gotofleft(self):
        value = 6
        print(value)
        hello_str="FORWARD LEFT"
        rospy.loginfo(hello_str)
        pub.publish(value)


    def gotorright(self):
        value = 7
        print(value)
        hello_str="REVERSE RIGHT "
        rospy.loginfo(hello_str)
        pub.publish(value)


    def gotorleft(self):
        value = 12
        print(value)

    def Stop(self):
        value = 0
        print(value)
        hello_str="STOP "
        rospy.loginfo(hello_str)
        pub.publish(value)

    def Loadmap(self):
        subprocess.Popen("cd missionplanner;mono MissionPlanner.exe", shell=True)
        rospy.loginfo("application open")

    def Loadmission(self):
        rospy.loginfo("loading mission")
        #pub.publish(value)
        subprocess.Popen("cd catkin_ws/src/qas/scripts;rosrun qas mp.py", shell=True)

    def runcamera(self):
        rospy.loginfo("Running Camera")
        #pub.publish(value)
        subprocess.Popen("cd ssd;python object_detection.py ", shell=True)

    def connectarduino(self):
        rospy.loginfo("CONNECTED TO ARDUINO")
        subprocess.Popen("rosrun rosserial_python serial_node.py /dev/ttyACM0", shell=True)

    def Autonomous(self):
        value = 8
        print(value)
        hello_str="STOP "
        rospy.loginfo(hello_str)
        pub.publish(value)



app = QApplication(sys.argv)
welcome = RcClass()
widget = QtWidgets.QStackedWidget()
widget.addWidget(welcome)
widget.setFixedHeight(351)
widget.setFixedWidth(671)
widget.show()
try:
    sys.exit(app.exec_())
except:
    print("Exiting")
